export interface Fornecedor {
  id: string;
  nome: string;
}
